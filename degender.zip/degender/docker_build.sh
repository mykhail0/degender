#!/bin/bash
docker build --tag 'degender:0.1' .
