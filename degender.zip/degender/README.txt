1. Create bot with @BotFather in telegram.
2. Paste your authorization key in the src/main/resources/application.properties
3. gradle clean build
4. ./docker_build.sh
5. ./docker_run.sh
6. ???
7. Enjoy texting with friends and the ease of checking and learning genders of German words!
