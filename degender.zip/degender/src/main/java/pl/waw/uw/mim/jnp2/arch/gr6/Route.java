package pl.waw.uw.mim.jnp2.arch.gr6;

import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.component.telegram.model.IncomingMessage;
import org.springframework.stereotype.Component;
import org.apache.camel.Exchange;
import java.util.ArrayList;
import org.apache.camel.component.jackson.JacksonDataFormat;
import org.apache.camel.component.jackson.ListJacksonDataFormat;

@Component
public class Route extends RouteBuilder {
    private static final String help = "/help";
    private static final String de = "/de";

    public void configure() throws Exception {
        onException(com.fasterxml.jackson.databind.exc.MismatchedInputException.class)
            .to("direct:error");

        restConfiguration().component("http").host("de.wiktionary.org");
        JacksonDataFormat fmt = new ListJacksonDataFormat(Section.class);

        from("telegram:bots")
            .bean(StringerBean.class).filter(simple("${body} != null"))
            .bean(IsCommandBean.class).filter(simple("${body} != null"))
            .choice()
                .when(simple("${body} == '/help'"))
                    .to("direct:help")
                .endChoice()
                .otherwise()
                    .to("direct:de")
                .endChoice()
            .end();


        from("direct:help").bean(HelpBean.class).to("telegram:bots");

        from("direct:de").bean(RemoveDeBean.class)
            .enrich().simple("rest:get:/w/api.php?action=parse&page=${body}&prop=sections&contentmodel=json&format=json")
            .bean(ArrayBean.class)
            .choice()
                .when(simple("${body} != null"))
                    .unmarshal(fmt)
                    .bean(WiktionaryRequest.class)
                    .to("telegram:bots")
                .endChoice()
                .otherwise()
                    .to("direct:error")
                .endChoice()
            .end();

        from("direct:error")
            .bean(ErrorBean.class)
            .to("telegram:bots");
    }

    // Returns null if message wasn't a command, otherwise returns the parameter.
    public class IsCommandBean {
        public String process(String msg) {
            if (msg == null)
                return null;
            if (msg.length() >= de.length() && msg.substring(0, de.length()).compareTo(de) == 0)
                return msg;
            return (msg.length() == help.length() && msg.substring(0, help.length()).compareTo(help) == 0) ? msg : null;
        }
    }

    public class ErrorBean {
        public void process(Exchange original) {
            original.getIn().setBody("Sorry, I could not find the gender.");
        }
    }

    public class HelpBean {
        public void process(Exchange original) {
            original.getIn().setBody("'/help' is for help and '/de Wort' is for genders.");
        }
    }

    // Removes '/de ' from the beginning of a command.
    public class RemoveDeBean {
        public String process(String msg) {
            return msg.substring(4);
        }
    }

    public class ArrayBean {
        public void process(Exchange original) {
            // Gets an array of sections of a de.wiktionary.org page.
            String newBody = original.getIn().getBody(String.class);
            System.out.println(newBody);
            int i = newBody.indexOf('['), j = newBody.lastIndexOf(']');
            if (i == -1 || j == -1) {
                original = null;
            } else {
                newBody = newBody.substring(i, j + 1);
                original.getIn().setBody(newBody);
            }
        }
    }

    public class StringerBean {
        public String process(IncomingMessage l) {
            return l == null ? null : l.getText();
        }
    }

    // Collect data about gender from the sections of the page.
    public class WiktionaryRequest {
        public String process(Exchange exchange) {
            return Section.getGender(exchange.getIn().getBody(ArrayList.class));
        }
    }
}
