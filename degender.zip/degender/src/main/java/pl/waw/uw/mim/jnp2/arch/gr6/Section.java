package pl.waw.uw.mim.jnp2.arch.gr6;

import java.util.AbstractCollection;
import java.util.ArrayList;
import java.util.LinkedHashSet;

// Class for extracting data from json.
public class Section {
    private int toclevel;
    private String level;
    private String line;
    private String number;
    private String index;
    private String fromtitle;
    private int byteoffset;
    private String anchor;

    // Collects data about gender from a vector of sections.
    public static String getGender(ArrayList<Section> l) {
        int german_num, i;
        i = german_num = 0;
        // Find the outer section of the noun.
        for ( ; i < l.size() && german_num == 0; ++i) {
            if (l.get(i).getToclevel() == 1 && l.get(i).german())
                german_num = l.get(i).mainNumber();
        }

        AbstractCollection<String> genders = new LinkedHashSet<String>();
        for ( ; i < l.size() && l.get(i).mainNumber() == german_num; ++i) {
            if (l.get(i).getToclevel() == 2 && l.get(i).getLine().length() > 12) {
                switch (l.get(i).getLine().charAt(12)) {
                    case 'm':
                        genders.add("der");
                        break;
                    case 'f':
                        genders.add("die");
                        break;
                    case 'n':
                        genders.add("das");
                        break;
                    default:
                        break;
                }
            }
        }

        String tmp = genders.toString();
        return tmp.substring(1, tmp.length() - 1);
    }

    // Sections have numbers in a format like "xx.xx.xx".
    // First x's are (word x language),
    // second x's are different words lexically in the same language but all with the same spelling.
    // As we need German nouns, we need to extract the first x's.
    public int mainNumber() {
        int i = 0;
        while (i < number.length() && ('0' <= number.charAt(i) && number.charAt(i) <= '9'))
            ++i;
        return i == 0 ? 0 : Integer.parseInt(number.substring(0, i));
    }

    // Checks if the main section (word x language one) is German.
    public boolean german() {
        return line.contains(" (Deutsch)");
    }

    // Checks if it's a noun.
    public boolean Substantiv() {
        String s = "Substantiv,";
        return s.length() < line.length() && line.substring(0, s.length()).compareTo(s) == 0;
    }
    
    // Getters and setters below, for Jackson.

    @Override
    public String toString() {
        return "Section{" +
                "toclevel=" + toclevel +
                ", line='" + line + '\'' +
                '}';
    }

    public void setToclevel(int toclevel) {
        this.toclevel = toclevel;
    }

    public void setLevel(String level) {
        this.level = level;
    }

    public void setLine(String line) {
        this.line = line;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public void setIndex(String index) {
        this.index = index;
    }

    public void setFromtitle(String fromtitle) {
        this.fromtitle = fromtitle;
    }

    public void setByteoffset(int byteoffset) {
        this.byteoffset = byteoffset;
    }

    public void setAnchor(String anchor) {
        this.anchor = anchor;
    }

    public int getToclevel() {
        return toclevel;
    }

    public String getLevel() {
        return level;
    }

    public String getLine() {
        return line;
    }

    public String getNumber() {
        return number;
    }

    public String getIndex() {
        return index;
    }

    public String getFromtitle() {
        return fromtitle;
    }

    public int getByteoffset() {
        return byteoffset;
    }

    public String getAnchor() {
        return anchor;
    }
}
